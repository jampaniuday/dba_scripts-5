-- +-------------------------------------------------------------------+
-- | FILE          : create_datebase920.sql                            |
-- | CREATION DATE : 24-MAY-2002                                       |
-- |                                                                   |
-- |  --------                                                         |
-- | |HISTORY |                                                        |
-- |  ---------------------------------------------------------------- |
-- | NAME DATE      DESCRIPTION                                        |
-- | ---- --------- -------------------------------------------------- |
-- | JMH  24-MAY-02 Created original file.                             |
-- +-------------------------------------------------------------------+

--
-- +-------------------------------------+
-- | CONNECT TO DATABASE                 |
-- | GET IN PARAMETERS                   |
-- +-------------------------------------+
--

connect SYS/change_on_install as SYSDBA


--
-- +-------------------------------------+
-- | Capture creation in this spool file |
-- +-------------------------------------+
--

spool create_CUSTDB_database.log

--
-- +-----------------------------+
-- | Create the initial database |
-- +-----------------------------+
--

startup nomount

SELECT 'START TIME: ' || TO_CHAR(sysdate, 'DD-MON-YYYY HH24:MI:SS') as Start_Time
FROM dual;


CREATE DATABASE "CUSTDB" NOARCHIVELOG
    MAXLOGFILES             32
    MAXLOGMEMBERS           5
    MAXDATAFILES            600
    MAXINSTANCES            10
    MAXLOGHISTORY           1000
DATAFILE
    '/u08/app/oradata/CUSTDB/system01.dbf' size 800M
    REUSE
    AUTOEXTEND ON   NEXT 50M   MAXSIZE UNLIMITED
    EXTENT MANAGEMENT LOCAL
DEFAULT TEMPORARY TABLESPACE temp
    TEMPFILE '/u07/app/oradata/CUSTDB/temp01.dbf' SIZE 500M REUSE
    AUTOEXTEND ON   NEXT 500M   MAXSIZE 1500M
UNDO TABLESPACE "UNDOTBS1"
    DATAFILE '/u06/app/oradata/CUSTDB/undotbs1_01.dbf' SIZE 400M REUSE
    AUTOEXTEND ON   NEXT 100M   MAXSIZE 1500M
CHARACTER SET               WE8ISO8859P1
NATIONAL CHARACTER SET      AL16UTF16
LOGFILE
  GROUP 1
 ('/u03/app/oradata/CUSTDB/redo_g01a.log',
  '/u04/app/oradata/CUSTDB/redo_g01b.log',
  '/u05/app/oradata/CUSTDB/redo_g01c.log') SIZE 100M,
  GROUP 2 
( '/u03/app/oradata/CUSTDB/redo_g02a.log',
  '/u04/app/oradata/CUSTDB/redo_g02b.log',
  '/u05/app/oradata/CUSTDB/redo_g02c.log') SIZE 100M,
  GROUP 3 
( '/u03/app/oradata/CUSTDB/redo_g03a.log',
  '/u04/app/oradata/CUSTDB/redo_g03b.log',
  '/u05/app/oradata/CUSTDB/redo_g03c.log') SIZE 100M
/

--
-- +-------------------------------+
-- | Create TABLESPACES tablespace |
-- +-------------------------------+
--

connect SYS/change_on_install as SYSDBA

CREATE TABLESPACE "CWMLITE"
  LOGGING DATAFILE '/u10/app/oradata/CUSTDB/cwmlite01.dbf' SIZE 50M REUSE
  AUTOEXTEND ON   NEXT 50M   MAXSIZE 1500M
  EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO;

CREATE TABLESPACE "DRSYS"
  LOGGING DATAFILE '/u10/app/oradata/CUSTDB/drsys01.dbf' SIZE 50M REUSE
  AUTOEXTEND ON   NEXT 50M   MAXSIZE 1500M
  EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO;

CREATE TABLESPACE "INDX"
  LOGGING DATAFILE '/u09/app/oradata/CUSTDB/indx01.dbf' SIZE 50M REUSE
  AUTOEXTEND ON   NEXT 50M   MAXSIZE 1500M
  EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO;

CREATE TABLESPACE "ODM"
  LOGGING DATAFILE '/u10/app/oradata/CUSTDB/odm01.dbf' SIZE 50M REUSE
  AUTOEXTEND ON   NEXT 50M   MAXSIZE 1500M
  EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO;

CREATE TABLESPACE "TOOLS"
  LOGGING DATAFILE '/u10/app/oradata/CUSTDB/tools01.dbf' SIZE 50M REUSE
  AUTOEXTEND ON   NEXT 50M   MAXSIZE 1500M
  EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO;

CREATE TABLESPACE "USERS"
  LOGGING DATAFILE '/u10/app/oradata/CUSTDB/users01.dbf' SIZE 50M REUSE
  AUTOEXTEND ON   NEXT 50M   MAXSIZE 1500M
  EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO;

CREATE TABLESPACE "XDB"
  LOGGING DATAFILE '/u10/app/oradata/CUSTDB/xdb01.dbf' SIZE 50M REUSE
  AUTOEXTEND ON   NEXT 50M   MAXSIZE 1500M
  EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO;

CREATE TABLESPACE "PERFSTAT"
  LOGGING DATAFILE '/u10/app/oradata/CUSTDB/perfstat01.dbf' SIZE 250M REUSE
  AUTOEXTEND OFF
  EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO;


--
-- +------------------------+
-- | RUN DB CATALOG SCRIPTS |
-- +------------------------+
--

connect SYS/change_on_install as SYSDBA

@$ORACLE_HOME/rdbms/admin/catalog.sql;
@$ORACLE_HOME/rdbms/admin/catexp7.sql;
@$ORACLE_HOME/rdbms/admin/catblock.sql;
@$ORACLE_HOME/rdbms/admin/catproc.sql;
@$ORACLE_HOME/rdbms/admin/catoctk.sql;
@$ORACLE_HOME/rdbms/admin/owminst.plb;

connect SYSTEM/manager
@$ORACLE_HOME/sqlplus/admin/pupbld.sql;

connect SYSTEM/manager
set echo on
@$ORACLE_HOME/sqlplus/admin/help/hlpbld.sql helpus.sql;

--
-- +-------------------------------------+
-- | CONNECT BACK TO DATABASE AS SYSDBA  |
-- +-------------------------------------+
--

connect SYS/change_on_install as SYSDBA

--
-- +----------------------------------------+
-- | TURN SPOOLING OFF AND SET THE TIME OFF |
-- +----------------------------------------+
--

SELECT 'END TIME: ' || TO_CHAR(sysdate, 'DD-MON-YYYY HH24:MI:SS') as End_Time
FROM dual;

spool off

--
-- +------------------+
-- | EXIT MAIN SCRIPT |
-- +------------------+
--

exit
