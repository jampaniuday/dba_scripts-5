connect SYS/change_on_install as SYSDBA

set echo on
spool ordinst.log

@$ORACLE_HOME/ord/admin/ordinst.sql;

spool off
exit;
