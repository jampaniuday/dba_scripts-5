# +-------------------------------------------------------------------+
# | FILE          : create_datebase8i.sql                             |
# | CREATION DATE : 09-FEB-2000                                       |
# |                                                                   |
# |  --------                                                         |
# | |HISTORY |                                                        |
# |  ---------------------------------------------------------------- |
# | NAME DATE      DESCRIPTION                                        |
# | ---- --------- -------------------------------------------------- |
# | JMH  09-FEB-00 Created original file.                             |
# +-------------------------------------------------------------------+


--
-- +-------------------------------------+
-- | Capture creation in this spool file |
-- +-------------------------------------+
--

spool  create_ORA817_database.log

--
-- +-----------------------------+
-- | Create the initial database |
-- +-----------------------------+
--

connect internal


startup nomount

SELECT 'START TIME: ' || TO_CHAR(sysdate, 'DD-MON-YYYY HH24:MI:SS') as Start_Time
FROM dual;

CREATE DATABASE "ORA817" NOARCHIVELOG
    MAXLOGFILES             32
    MAXLOGMEMBERS           5
    MAXDATAFILES            600
    MAXINSTANCES            10
    MAXLOGHISTORY           1000
    CHARACTER SET           WE8ISO8859P1
    NATIONAL CHARACTER SET  WE8ISO8859P1
LOGFILE
  GROUP 1
 ('/u03/app/oradata/ORA817/redo_g01a.log',
  '/u04/app/oradata/ORA817/redo_g01b.log',
  '/u05/app/oradata/ORA817/redo_g01c.log') SIZE 1M,
  GROUP 2 
( '/u03/app/oradata/ORA817/redo_g02a.log',
  '/u04/app/oradata/ORA817/redo_g02b.log',
  '/u05/app/oradata/ORA817/redo_g02c.log') SIZE 1M,
  GROUP 3 
( '/u03/app/oradata/ORA817/redo_g03a.log',
  '/u04/app/oradata/ORA817/redo_g03b.log',
  '/u05/app/oradata/ORA817/redo_g03c.log') SIZE 1M
DATAFILE
  '/u08/app/oradata/ORA817/system01.dbf' size 500M AUTOEXTEND OFF;
/


--
-- +-------------------------------------------------+
-- | Need a basic rollback segment before proceeding |
-- +-------------------------------------------------+
--

CREATE ROLLBACK SEGMENT r000
  TABLESPACE system
  STORAGE (
    INITIAL    1M
    NEXT       1M
    MINEXTENTS 2
  );
ALTER ROLLBACK SEGMENT r000 ONLINE;

--
-- +-----------------+
-- | RUN catalog.sql |
-- +-----------------+
--

@$ORACLE_HOME/rdbms/admin/catalog.sql

--
-- +-------------------------+
-- | ALTER SYSTEM TABLESPACE |
-- +-------------------------+
--

ALTER TABLESPACE system
  DEFAULT STORAGE (
    INITIAL 64K NEXT 64K MINEXTENTS 1 MAXEXTENTS UNLIMITED PCTINCREASE 0
  );

ALTER TABLESPACE SYSTEM MINIMUM EXTENT 64K;


--
-- +-----------------------------------------+
-- | Create tablespace for Rollback Segments |
-- +-----------------------------------------+
--

CREATE TABLESPACE "RBS1" 
    LOGGING 
    DATAFILE '/u06/app/oradata/ORA817/rbs1_01.dbf' SIZE 250M 
    REUSE
    AUTOEXTEND ON   NEXT 250M   MAXSIZE 1500M
    EXTENT MANAGEMENT LOCAL UNIFORM SIZE 5M
/

CREATE TABLESPACE "RBS2" 
    LOGGING 
    DATAFILE '/u06/app/oradata/ORA817/rbs2_01.dbf' SIZE 250M 
    REUSE
    AUTOEXTEND ON   NEXT 250M   MAXSIZE 1500M
    EXTENT MANAGEMENT LOCAL UNIFORM SIZE 5M
/


--
-- +--------------------------+
-- | Create Rollback Segments |
-- +--------------------------+
--

CREATE PUBLIC ROLLBACK SEGMENT rbs1
  TABLESPACE rbs1
  STORAGE (
     MINEXTENTS  2
     MAXEXTENTS  unlimited
     OPTIMAL     20M
  );
ALTER ROLLBACK SEGMENT rbs1 ONLINE;


CREATE PUBLIC ROLLBACK SEGMENT rbs2
  TABLESPACE rbs2
  STORAGE (
     MINEXTENTS  2
     MAXEXTENTS  unlimited
     OPTIMAL     20M
  );
ALTER ROLLBACK SEGMENT rbs2 ONLINE;


CREATE PUBLIC ROLLBACK SEGMENT rbs3
  TABLESPACE rbs1
  STORAGE (
    MINEXTENTS  2
    MAXEXTENTS  unlimited
    OPTIMAL     20M
  );
ALTER ROLLBACK SEGMENT rbs3 ONLINE;


CREATE PUBLIC ROLLBACK SEGMENT rbs4
  TABLESPACE rbs2
  STORAGE (
    MINEXTENTS  2
    MAXEXTENTS  unlimited
    OPTIMAL     20M);
ALTER ROLLBACK SEGMENT rbs4 ONLINE;


CREATE PUBLIC ROLLBACK SEGMENT rbs5
  TABLESPACE rbs1
  STORAGE (
    MINEXTENTS  2
    MAXEXTENTS  unlimited
    OPTIMAL     20M
  );
ALTER ROLLBACK SEGMENT rbs5 ONLINE;


CREATE PUBLIC ROLLBACK SEGMENT rbs6
  TABLESPACE rbs2
  STORAGE (
    MINEXTENTS  2
    MAXEXTENTS  unlimited
    OPTIMAL     20M);
ALTER ROLLBACK SEGMENT rbs6 ONLINE;


CREATE PUBLIC ROLLBACK SEGMENT rbs7
  TABLESPACE rbs1
  STORAGE (
    MINEXTENTS  2
    MAXEXTENTS  unlimited
    OPTIMAL     20M
  );
ALTER ROLLBACK SEGMENT rbs7 ONLINE;


CREATE PUBLIC ROLLBACK SEGMENT rbs8
  TABLESPACE rbs2
  STORAGE (
    MINEXTENTS  2
    MAXEXTENTS  unlimited
    OPTIMAL     20M
  );
ALTER ROLLBACK SEGMENT rbs8 ONLINE;

--
-- +--------------------------+
-- | Create a TEMP tablespace |
-- +--------------------------+
--


CREATE TEMPORARY TABLESPACE "TEMP"
  TEMPFILE '/u07/app/oradata/ORA817/temp01.dbf' SIZE 250M REUSE
  AUTOEXTEND ON NEXT 250M MAXSIZE 1500M
  EXTENT MANAGEMENT LOCAL UNIFORM SIZE 1M;


--
-- +-----------------------------------------------+
-- | ALTER TEMPORARY TABLESPACE FOR SYS AND SYSTEM |
-- +-----------------------------------------------+
--

ALTER USER SYS  TEMPORARY TABLESPACE TEMP;
ALTER USER SYSTEM TEMPORARY TABLESPACE TEMP;

--
-- +--------------------------------------------+
-- | Create a PERFSTAT tablespace for STATSPACK |
-- +--------------------------------------------+
--

CREATE TABLESPACE "PERFSTAT"
  LOGGING
  DATAFILE '/u10/app/oradata/ORA817/perfstat01.dbf' SIZE 250M REUSE
  AUTOEXTEND OFF
  EXTENT MANAGEMENT LOCAL AUTOALLOCATE;


--
-- +--------------------------------------------+
-- | Create a GENERIC Tablespaces               |
-- +--------------------------------------------+
--

CREATE TABLESPACE "USERS"
  LOGGING
  DATAFILE '/u10/app/oradata/ORA817/users01.dbf' SIZE 25M
  REUSE
  AUTOEXTEND ON
  NEXT       10M
  MAXSIZE    250M
  EXTENT MANAGEMENT LOCAL AUTOALLOCATE
/

--
-- +---------------------------+
-- | RUN ALL REMAINING SCRIPTS |
-- +---------------------------+
--

@$ORACLE_HOME/rdbms/admin/catproc.sql
@$ORACLE_HOME/rdbms/admin/caths.sql
@$ORACLE_HOME/rdbms/admin/catblock.sql
@$ORACLE_HOME/rdbms/admin/dbmspool.sql
@$ORACLE_HOME/rdbms/admin/prvtpool.plb

commit;

connect system/manager
@$ORACLE_HOME/sqlplus/admin/pupbld.sql
commit;

connect internal

--
-- +-------------------------------------------+
-- | TAKE THE INITIAL ROLLBACK SEGMENT OFFLINE |
-- +-------------------------------------------+
--

ALTER ROLLBACK SEGMENT r000 OFFLINE;


--
-- +----------------------------------------+
-- | TURN SPOOLING OFF AND SET THE TIME OFF |
-- +----------------------------------------+
--

SELECT 'END TIME: ' || TO_CHAR(sysdate, 'DD-MON-YYYY HH24:MI:SS') as End_Time
FROM dual;

REM spool off

--
-- +------------------+
-- | EXIT MAIN SCRIPT |
-- +------------------+
--


# ==============
# EXITING SCRIPT
# ==============

exit
