#!/bin/sh

$ORACLE_HOME/bin/svrmgrl << EOF
spool iMediainst.log;
connect internal/oracle
@$ORACLE_HOME/ord/im/admin/iminst.sql;
spool off
exit;

EOF
