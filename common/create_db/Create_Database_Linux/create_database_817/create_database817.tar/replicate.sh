#!/bin/sh

$ORACLE_HOME/bin/svrmgrl << EOF
spool spoolrep.log;
connect internal/oracle
@$ORACLE_HOME/rdbms/admin/catrep.sql
spool off
exit

EOF
