#!/bin/sh

$ORACLE_HOME/bin/svrmgrl << EOF
spool mdinst.log;
connect internal/oracle
@$ORACLE_HOME/md/admin/mdinst.sql
spool off
exit

EOF
