#!/bin/ksh

./crdb.sh > crdb.log 2>&1
