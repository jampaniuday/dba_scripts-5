connect SYS/change_on_install as SYSDBA

set echo on
spool interMedia.log

@$ORACLE_HOME/ord/im/admin/iminst.sql;

spool off
exit;
