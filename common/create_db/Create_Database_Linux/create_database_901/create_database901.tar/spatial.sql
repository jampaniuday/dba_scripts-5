connect SYSTEM/manager

set echo on
spool spatial.log

@$ORACLE_HOME/md/admin/mdinst.sql;

spool off
exit;
