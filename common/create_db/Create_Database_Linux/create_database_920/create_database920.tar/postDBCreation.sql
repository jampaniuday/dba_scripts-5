connect SYS/change_on_install as SYSDBA

set echo on
spool postDBCreation1.log

REM +-------------------------------------------------+
REM | UTiLity script Recompile invalid Pl/sql modules |
REM +-------------------------------------------------+

@$ORACLE_HOME/rdbms/admin/utlrp.sql;


REM +----------------------------------+
REM | PUT DATABASE IN ARCHIVE LOG MODE |
REM +----------------------------------+

shutdown immediate;
connect SYS/change_on_install as SYSDBA

startup mount;
-- alter database archivelog;
alter database open;

connect SYS/change_on_install as SYSDBA
shutdown immediate;

spool off


REM +--------------------------------------+
REM | CREATE SERVER MANAGED PARAMETER FILE |
REM +--------------------------------------+

connect SYS/change_on_install as SYSDBA
set echo on

spool postDBCreation2.log

CREATE SPFILE='$ORACLE_HOME/dbs/spfile$ORACLE_SID.ora' FROM pfile='$ORACLE_HOME/dbs/init$ORACLE_SID.ora';

connect SYS/change_on_install as SYSDBA
startup open;

spool off
exit;
