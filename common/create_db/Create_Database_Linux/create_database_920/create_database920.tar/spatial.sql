connect SYS/change_on_install as SYSDBA

set echo on
spool spatial.log

@$ORACLE_HOME/md/admin/mdinst.sql;

spool off
exit;
