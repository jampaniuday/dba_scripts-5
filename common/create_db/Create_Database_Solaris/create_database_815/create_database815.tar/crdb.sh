#!/bin/sh

echo "+---------------------------+"
echo "| Staring crdb815...        |"
echo "+---------------------------+"

ORACLE_SID=ORA815
export ORACLE_SID

ORACLE_BASE=/u01/app/oracle
export ORACLE_BASE

ORACLE_HOME=$ORACLE_BASE/product/8.1.5
export ORACLE_HOME

rm $ORACLE_HOME/dbs/orapwORA815
$ORACLE_HOME/bin/orapwd file=$ORACLE_HOME/dbs/orapwORA815 password=change_on_install entries=50

ln -s $ORACLE_BASE/admin/$ORACLE_SID/pfile/init$ORACLE_SID.ora $ORACLE_HOME/dbs/init$ORACLE_SID.ora

echo "+---------------------------+"
echo "| Creating Database...      |"
echo "+---------------------------+"

./crdbDB.sh

echo "+---------------------------+"
echo "| Installing Context...     |"
echo "+---------------------------+"

$ORACLE_HOME/bin/svrmgrl << EOF
connect sys/change_on_install
CREATE TABLESPACE DRSYS 
  DATAFILE '/u10/app/oradata/$ORACLE_SID/drsys01.dbf' SIZE 100M REUSE
  DEFAULT STORAGE (
    INITIAL     64K
    NEXT        64K
    MINEXTENTS  1
    MAXEXTENTS  UNLIMITED
    PCTINCREASE 0
);
exit;

EOF

./context.sh

echo "+---------------------------+"
echo "| Installing Ordint...      |"
echo "+---------------------------+"

./ordinst.sh

echo "+---------------------------+"
echo "| Installing Spatial...     |"
echo "+---------------------------+"

./spatial1.sh

echo "+---------------------------+"
echo "| Installing Replication... |"
echo "+---------------------------+"

./replicate.sh

echo "+---------------------------+"
echo "| Installing InterMedia...  |"
echo "+---------------------------+"

./iMedia.sh

echo "+---------------------------+"
echo "| Installing SQL*Plus Help..|"
echo "+---------------------------+"

echo "  ----------------"
echo "  -- sqlplus.sh..."
echo "  ----------------"
./sqlplus.sh

echo "  -----------------"
echo "  -- sqlplus2.sh..."
echo "  -----------------"
./sqlplus2.sh

echo "  -----------------"
echo "  -- sqlplus1.sh..."
echo "  -----------------"
./sqlplus1.sh

echo "+---------------------------+"
echo "| Installing Timeseries...  |"
echo "+---------------------------+"

./timeseries.sh

echo "+---------------------------+"
echo "| Installing Virage...      |"
echo "+---------------------------+"

./virage.sh

echo "+---------------------------+"
echo "| Installing Java...        |"
echo "+---------------------------+"

./java.sh

echo "+---------------------------+"
echo "| Post Install...          |"
echo "+---------------------------+"

./postInstall.sh

echo "+-------------------+"
echo "| Ending crdb815... |"
echo "+-------------------+"

exit
