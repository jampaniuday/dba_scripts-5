#!/bin/sh

$ORACLE_HOME/bin/svrmgrl << EOF
spool jvminst.log;
connect internal/
@$ORACLE_HOME/javavm/install/initjvm.sql;
spool off
exit;

EOF
