#!/bin/sh

$ORACLE_HOME/bin/svrmgrl << EOF
spool ordinst.log;
connect internal/
@$ORACLE_HOME/ord/admin/ordinst.sql
spool off
exit;

EOF
