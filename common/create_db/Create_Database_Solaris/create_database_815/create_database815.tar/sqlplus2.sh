#!/bin/sh

$ORACLE_HOME/bin/sqlldr userid=system/manager control=$ORACLE_HOME/sqlplus/admin/help/plushelp.ctl direct=true