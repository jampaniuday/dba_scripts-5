#!/bin/sh

$ORACLE_HOME/bin/svrmgrl << EOF
spool tsinst.log;
connect internal/
@$ORACLE_HOME/ord/ts/admin/tsinst.sql;
spool off
exit;

EOF
