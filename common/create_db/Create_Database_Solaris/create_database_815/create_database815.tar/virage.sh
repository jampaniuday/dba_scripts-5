#!/bin/sh

$ORACLE_HOME/bin/svrmgrl << EOF
spool virinst.log;
connect internal/
@$ORACLE_HOME/ord/vir/admin/virinst.sql;
spool off
exit;

EOF
