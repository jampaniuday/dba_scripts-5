#!/bin/sh

# cd $ORACLE_HOME/ctx/admin

$ORACLE_HOME/bin/sqlplus << EOF
internal
spool spoolctx.log;
@$ORACLE_HOME/ctx/admin/dr0csys ctxsys DRSYS DRSYS
connect ctxsys/ctxsys
@$ORACLE_HOME/ctx/admin/dr0inst $ORACLE_HOME/ctx/lib/libctxx8.so
@$ORACLE_HOME/ctx/admin/defaults/drdefus.sql
spool off
exit

EOF
