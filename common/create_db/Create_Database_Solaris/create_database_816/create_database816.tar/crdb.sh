#!/bin/sh

echo "+---------------------------+"
echo "| Staring crdb816...        |"
echo "+---------------------------+"

ORACLE_SID=ORA816
export ORACLE_SID

ORACLE_BASE=/u01/app/oracle
export ORACLE_BASE

ORACLE_HOME=$ORACLE_BASE/product/8.1.6
export ORACLE_HOME

rm $ORACLE_HOME/dbs/orapw$ORACLE_SID
$ORACLE_HOME/bin/orapwd file=$ORACLE_HOME/dbs/orapw$ORACLE_SID password=change_on_install entries=50

ln -s $ORACLE_BASE/admin/$ORACLE_SID/pfile/init$ORACLE_SID.ora $ORACLE_HOME/dbs/init$ORACLE_SID.ora


echo "+---------------------------+"
echo "| Creating Directories...   |"
echo "+---------------------------+"

mkdir /u03/app/oradata/$ORACLE_SID
mkdir /u03/app/oradata/$ORACLE_SID/export
mkdir /u04/app/oradata/$ORACLE_SID
mkdir /u05/app/oradata/$ORACLE_SID
mkdir /u06/app/oradata/$ORACLE_SID
mkdir /u07/app/oradata/$ORACLE_SID
mkdir /u07/app/oradata/$ORACLE_SID/archive
mkdir /u08/app/oradata/$ORACLE_SID
mkdir /u09/app/oradata/$ORACLE_SID
mkdir /u10/app/oradata/$ORACLE_SID

echo "+---------------------------+"
echo "| Creating Database...      |"
echo "+---------------------------+"

./crdbDB.sh

echo "+---------------------------+"
echo "| Installing Replication... |"
echo "+---------------------------+"

./replicate.sh

echo "+---------------------------+"
echo "| Installing Java...        |"
echo "+---------------------------+"

./java.sh

echo "+---------------------------+"
echo "| Installing Ordint...      |"
echo "+---------------------------+"

./ordinst.sh

echo "+---------------------------+"
echo "| Installing InterMedia...  |"
echo "+---------------------------+"

./iMedia.sh

$ORACLE_HOME/bin/svrmgrl << EOF
connect internal/oracle
CREATE TABLESPACE DRSYS 
  DATAFILE '/u10/app/oradata/$ORACLE_SID/drsys01.dbf' SIZE 100M REUSE
  DEFAULT STORAGE (
    INITIAL     64K
    NEXT        64K
    MINEXTENTS  1
    MAXEXTENTS  UNLIMITED
    PCTINCREASE 0
);
exit;

EOF

./context.sh

echo "+---------------------------+"
echo "| Installing Spatial...     |"
echo "+---------------------------+"

./spatial1.sh

echo "+---------------------------+"
echo "| Installing SQL*Plus Help..|"
echo "+---------------------------+"

./sqlplus.sh

echo "+---------------------------+"
echo "| Installing Timeseries...  |"
echo "+---------------------------+"

./timeseries.sh

echo "+---------------------------+"
echo "| Installing Virage...      |"
echo "+---------------------------+"

./virage.sh

echo "+---------------------------+"
echo "| Post Install...          |"
echo "+---------------------------+"

./postInstall.sh

echo "+-------------------+"
echo "| Ending crdb816... |"
echo "+-------------------+"

exit
