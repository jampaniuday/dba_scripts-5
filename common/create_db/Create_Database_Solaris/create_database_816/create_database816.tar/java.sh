#!/bin/sh

$ORACLE_HOME/bin/svrmgrl << EOF
spool jvminst.log;
connect internal/oracle
@$ORACLE_HOME/javavm/install/initjvm.sql;
spool off
spool initplsj.log;
@$ORACLE_HOME/rdbms/admin/initplsj.sql
spool off
spool initaqjms.log;
@$ORACLE_HOME/rdbms/admin/initaqjms.sql
spool off
spool initrepapi.log;
@$ORACLE_HOME/rdbms/admin/initrepapi.sql
spool off
exit;

EOF
