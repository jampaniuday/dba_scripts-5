#!/bin/sh

$ORACLE_HOME/bin/svrmgrl << EOF
spool ordinst.log;
connect internal/oracle
@$ORACLE_HOME/ord/admin/ordinst.sql
spool off
exit;

EOF
