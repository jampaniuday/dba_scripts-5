#!/bin/sh

$ORACLE_HOME/bin/sqlplus << EOF
system/manager
@$ORACLE_HOME/sqlplus/admin/help/helpbld.sql helpus.sql
