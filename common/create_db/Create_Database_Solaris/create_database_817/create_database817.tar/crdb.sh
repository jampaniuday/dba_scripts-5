#!/bin/sh

echo "+---------------------------+"
echo "| Staring crdb817...        |"
echo "+---------------------------+"

ORACLE_SID=ORA817
export ORACLE_SID

ORACLE_BASE=/u01/app/oracle
export ORACLE_BASE

ORACLE_HOME=$ORACLE_BASE/product/8.1.7
export ORACLE_HOME

rm $ORACLE_HOME/dbs/orapw$ORACLE_SID
$ORACLE_HOME/bin/orapwd file=$ORACLE_HOME/dbs/orapw$ORACLE_SID password=change_on_install entries=50

ln -s $ORACLE_BASE/admin/$ORACLE_SID/pfile/init$ORACLE_SID.ora $ORACLE_HOME/dbs/init$ORACLE_SID.ora

echo "+---------------------------+"
echo "| Creating Directories...   |"
echo "+---------------------------+"

mkdir /u03/app/oradata/$ORACLE_SID
mkdir /u03/app/oradata/$ORACLE_SID/export
mkdir /u04/app/oradata/$ORACLE_SID
mkdir /u05/app/oradata/$ORACLE_SID
mkdir /u06/app/oradata/$ORACLE_SID
mkdir /u07/app/oradata/$ORACLE_SID
mkdir /u07/app/oradata/$ORACLE_SID/archive
mkdir /u08/app/oradata/$ORACLE_SID
mkdir /u09/app/oradata/$ORACLE_SID
mkdir /u10/app/oradata/$ORACLE_SID

echo "+---------------------------+"
echo "| Creating Database...      |"
echo "+---------------------------+"

./crdbDB.sh

echo "+---------------------------+"
echo "| Installing Replication... |"
echo "+---------------------------+"

./replicate.sh

echo "+---------------------------+"
echo "| Installing Java...        |"
echo "+---------------------------+"

./java.sh

echo "+------------------------------------------------+"
echo "| Installing Ordint...                           |"
echo "| ---------------------------------------------- |"
echo "| Creates the following users:                   |"
echo "|   - ORDSYS :    The user for Oracle cartridges.|"
echo "|                 This user ID is the standard   |"
echo "|                 Oracle database account with   |"
echo "|                 special privileges for data    |"
echo "|                 cartridges. Users will need to |"
echo "|                 decide on a password for the   |"
echo "|                 ORDSYS user as its default     |"
echo "|                 password is ORDSYS.            |"
echo "|  - ORDPLUGINS :                                |"
echo "|  - MDSYS      :                                |"
echo "|  - ORDSYS     :                                |"
echo "| This script also creates the roles for         |"
echo "| timeseries.                                    |"
echo "| This script also installs the UTL_RAW package. |"
echo "+------------------------------------------------+"

./ordinst.sh

echo "+------------------------------------------------+"
echo "| Installing InterMedia...                       |"
echo "| ---------------------------------------------- |"
echo "| Make sure that ordinst.sql has been run before |"
echo "| attempting to run interMedia.                  |"
echo "+------------------------------------------------+"

./iMedia.sh

$ORACLE_HOME/bin/svrmgrl << EOF
connect internal/oracle
CREATE TABLESPACE "DRSYS"
  LOGGING DATAFILE '/u10/app/oradata/$ORACLE_SID/drsys01.dbf' SIZE 100M REUSE
  AUTOEXTEND ON NEXT 1M MAXSIZE UNLIMITED
  EXTENT MANAGEMENT LOCAL;
);
exit;

EOF

./context.sh

echo "+---------------------------+"
echo "| Installing Spatial...     |"
echo "+---------------------------+"

./spatial1.sh

echo "+---------------------------+"
echo "| Installing SQL*Plus Help..|"
echo "+---------------------------+"

./sqlplus.sh

echo "+--------------------------------------------+"
echo "| Installing Timeseries...                   |"
echo "| ------------------------------------------ |"
echo "| Installed under the database user ORDSYS   |"
echo "| (Time Series Data Cartridge)               |"
echo "+--------------------------------------------+"

./timeseries.sh

echo "+------------------------------------------------+"
echo "| Installing Virage...                           |"
echo "| ---------------------------------------------- |"
echo "| Installed under the database user ORDSYS       |"
echo "| Virage (VIR) Data Cartridge                    |"
echo "| (Visual Information Retrieval Cartridge)       |"
echo "| For more information about virage see:         |"
echo "|     http://www.virage.com                      |"
echo "+------------------------------------------------+"

./virage.sh

echo "+---------------------------+"
echo "| Post Install...           |"
echo "+---------------------------+"

./postInstall.sh

echo "+-------------------+"
echo "| Ending crdb817... |"
echo "+-------------------+"

exit
