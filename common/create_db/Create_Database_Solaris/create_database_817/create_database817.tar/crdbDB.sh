#!/bin/sh

$ORACLE_HOME/bin/svrmgrl << EOF
connect internal/oracle
spool create_database.log;
@create_database.sql
spool off
exit

EOF
