#!/bin/sh

$ORACLE_HOME/bin/svrmgrl << EOF
spool postInstall.log;
connect internal/
shutdown;
startup mount;
-- alter database archivelog;
alter database open;
spool off
exit;

EOF
