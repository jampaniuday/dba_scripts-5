#!/bin/sh

echo "+---------------------------+"
echo "| Staring crdb901...        |"
echo "+---------------------------+"

ORACLE_SID=ORA901
export ORACLE_SID

ORACLE_BASE=/u01/app/oracle
export ORACLE_BASE

ORACLE_HOME=$ORACLE_BASE/product/9.0.1
export ORACLE_HOME

rm $ORACLE_HOME/dbs/orapw$ORACLE_SID
$ORACLE_HOME/bin/orapwd file=$ORACLE_HOME/dbs/orapw$ORACLE_SID password=change_on_install entries=50

ln -s $ORACLE_BASE/admin/$ORACLE_SID/pfile/init$ORACLE_SID.ora $ORACLE_HOME/dbs/init$ORACLE_SID.ora

echo "+---------------------------+"
echo "| Creating Directories...   |"
echo "+---------------------------+"

mkdir /u03/app/oradata/$ORACLE_SID
mkdir /u03/app/oradata/$ORACLE_SID/export
mkdir /u04/app/oradata/$ORACLE_SID
mkdir /u05/app/oradata/$ORACLE_SID
mkdir /u06/app/oradata/$ORACLE_SID
mkdir /u07/app/oradata/$ORACLE_SID
mkdir /u07/app/oradata/$ORACLE_SID/archive
mkdir /u08/app/oradata/$ORACLE_SID
mkdir /u09/app/oradata/$ORACLE_SID
mkdir /u10/app/oradata/$ORACLE_SID


echo "+---------------------------+"
echo "| Creating Database...      |"
echo "+---------------------------+"

$ORACLE_HOME/bin/sqlplus /nolog @create_database.sql

echo "+---------------------------+"
echo "| Installing Java...        |"
echo "+---------------------------+"

$ORACLE_HOME/bin/sqlplus /nolog @JServer.sql

echo "+---------------------------+"
echo "| Installing ordinst...     |"
echo "+---------------------------+"

$ORACLE_HOME/bin/sqlplus /nolog @ordinst.sql

echo "+---------------------------+"
echo "| Installing interMedia...  |"
echo "+---------------------------+"

$ORACLE_HOME/bin/sqlplus /nolog @interMedia.sql

echo "+---------------------------+"
echo "| Installing context...     |"
echo "+---------------------------+"

$ORACLE_HOME/bin/sqlplus /nolog @context.sql


echo "+---------------------------+"
echo "| Installing ordinst...     |"
echo "+---------------------------+"

$ORACLE_HOME/bin/sqlplus /nolog @ordinst.sql


echo "+---------------------------+"
echo "| Installing spatial...     |"
echo "+---------------------------+"

$ORACLE_HOME/bin/sqlplus /nolog @spatial.sql


echo "+---------------------------+"
echo "| Installing ultraSearch... |"
echo "+---------------------------+"

$ORACLE_HOME/bin/sqlplus /nolog @ultraSearch.sql


echo "+---------------------------+"
echo "| Installing cwmlite...     |"
echo "+---------------------------+"

$ORACLE_HOME/bin/sqlplus /nolog @cwmlite.sql


echo "+---------------------------+"
echo "| Installing demoSchemas... |"
echo "+---------------------------+"

# $ORACLE_HOME/bin/sqlplus /nolog @demoSchemas.sql


echo "+------------------------------+"
echo "| Installing postDBCreation... |"
echo "+------------------------------+"

$ORACLE_HOME/bin/sqlplus /nolog @postDBCreation.sql


echo "+-------------------+"
echo "| Ending crdb901... |"
echo "+-------------------+"

exit
