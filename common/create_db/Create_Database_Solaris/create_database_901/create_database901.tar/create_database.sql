-- +-------------------------------------------------------------------+
-- | FILE          : create_datebase8i.sql                             |
-- | CREATION DATE : 21-JUN-2001                                       |
-- |                                                                   |
-- |  --------                                                         |
-- | |HISTORY |                                                        |
-- |  ---------------------------------------------------------------- |
-- | NAME DATE      DESCRIPTION                                        |
-- | ---- --------- -------------------------------------------------- |
-- | JMH  21-JUN-01 Created original file.                             |
-- +-------------------------------------------------------------------+

--
-- +-------------------------------------+
-- | CONNECT TO DATABASE                 |
-- +-------------------------------------+
--

connect SYS/change_on_install as SYSDBA

--
-- +-------------------------------------+
-- | Capture creation in this spool file |
-- +-------------------------------------+
--

spool create_ORA901_database.log

--
-- +-----------------------------+
-- | Create the initial database |
-- +-----------------------------+
--

startup nomount

SELECT 'START TIME: ' || TO_CHAR(sysdate, 'DD-MON-YYYY HH24:MI:SS') as Start_Time
FROM dual;


CREATE DATABASE "ORA901" NOARCHIVELOG
    MAXLOGFILES             32
    MAXLOGMEMBERS           5
    MAXDATAFILES            600
    MAXINSTANCES            10
    MAXLOGHISTORY           1000
DATAFILE
  '/u08/app/oradata/ORA901/system01.dbf' size 800M
  REUSE
  AUTOEXTEND ON   NEXT 50M   MAXSIZE UNLIMITED
DEFAULT TEMPORARY TABLESPACE temp
  TEMPFILE '/u07/app/oradata/ORA901/temp01.dbf' SIZE 500M REUSE
  EXTENT MANAGEMENT LOCAL UNIFORM SIZE 1M
  AUTOEXTEND ON   NEXT 500M   MAXSIZE 1500M
UNDO TABLESPACE "UNDOTBS" DATAFILE 
  '/u06/app/oradata/ORA901/undotbs01.dbf' SIZE 400M
  REUSE
  AUTOEXTEND ON   NEXT 100M   MAXSIZE 1500M
CHARACTER SET               WE8ISO8859P1
NATIONAL CHARACTER SET      UTF8
LOGFILE
  GROUP 1
 ('/u03/app/oradata/ORA901/redo_g01a.log',
  '/u04/app/oradata/ORA901/redo_g01b.log',
  '/u05/app/oradata/ORA901/redo_g01c.log') SIZE 100M,
  GROUP 2 
( '/u03/app/oradata/ORA901/redo_g02a.log',
  '/u04/app/oradata/ORA901/redo_g02b.log',
  '/u05/app/oradata/ORA901/redo_g02c.log') SIZE 100M,
  GROUP 3 
( '/u03/app/oradata/ORA901/redo_g03a.log',
  '/u04/app/oradata/ORA901/redo_g03b.log',
  '/u05/app/oradata/ORA901/redo_g03c.log') SIZE 100M
/

--
-- +-------------------------------+
-- | Create TABLESPACES tablespace |
-- +-------------------------------+
--

connect SYS/change_on_install as SYSDBA

CREATE TABLESPACE "CWMLITE"
  LOGGING DATAFILE '/u10/app/oradata/ORA901/cwmlite01.dbf' SIZE 50M REUSE
  AUTOEXTEND ON   NEXT 50M   MAXSIZE 1000M
  EXTENT MANAGEMENT LOCAL AUTOALLOCATE;

CREATE TABLESPACE "DRSYS"
  LOGGING DATAFILE '/u10/app/oradata/ORA901/drsys01.dbf' SIZE 50M REUSE
  AUTOEXTEND ON   NEXT 50M   MAXSIZE 1000M
  EXTENT MANAGEMENT LOCAL AUTOALLOCATE;

-- CREATE TABLESPACE "EXAMPLE"
--   LOGGING DATAFILE '/u10/app/oradata/ORA901/example01.dbf' SIZE 50M REUSE
--   AUTOEXTEND ON   NEXT 50M   MAXSIZE 1000M
--   EXTENT MANAGEMENT LOCAL AUTOALLOCATE;

CREATE TABLESPACE "INDX"
  LOGGING DATAFILE '/u09/app/oradata/ORA901/indx01.dbf' SIZE 50M REUSE
  AUTOEXTEND ON   NEXT 50M   MAXSIZE 1000M
  EXTENT MANAGEMENT LOCAL AUTOALLOCATE;

CREATE TABLESPACE "TOOLS"
  LOGGING DATAFILE '/u10/app/oradata/ORA901/tools01.dbf' SIZE 50M REUSE
  AUTOEXTEND ON   NEXT 50M   MAXSIZE 1000M
  EXTENT MANAGEMENT LOCAL AUTOALLOCATE;

CREATE TABLESPACE "USERS"
  LOGGING DATAFILE '/u10/app/oradata/ORA901/users01.dbf' SIZE 50M REUSE
  AUTOEXTEND ON   NEXT 50M   MAXSIZE 1000M
  EXTENT MANAGEMENT LOCAL AUTOALLOCATE;

CREATE TABLESPACE "PERFSTAT"
  LOGGING DATAFILE '/u10/app/oradata/ORA901/perfstat01.dbf' SIZE 250M REUSE
  AUTOEXTEND OFF
  EXTENT MANAGEMENT LOCAL AUTOALLOCATE;

--
-- +------------------------+
-- | RUN DB CATALOG SCRIPTS |
-- +------------------------+
--

connect SYS/change_on_install as SYSDBA

@$ORACLE_HOME/rdbms/admin/catalog.sql;
@$ORACLE_HOME/rdbms/admin/catexp7.sql;
@$ORACLE_HOME/rdbms/admin/catblock.sql;
@$ORACLE_HOME/rdbms/admin/catproc.sql;
@$ORACLE_HOME/rdbms/admin/catoctk.sql;
@$ORACLE_HOME/rdbms/admin/catobtk.sql;
@$ORACLE_HOME/rdbms/admin/caths.sql;
@$ORACLE_HOME/rdbms/admin/owminst.plb;

connect SYSTEM/manager
@$ORACLE_HOME/sqlplus/admin/pupbld.sql;

connect SYSTEM/manager
set echo on
@$ORACLE_HOME/sqlplus/admin/help/hlpbld.sql helpus.sql;

--
-- +-------------------------------------+
-- | CONNECT TO DATABASE                 |
-- +-------------------------------------+
--

connect SYS/change_on_install as SYSDBA

--
-- +----------------------------------------+
-- | TURN SPOOLING OFF AND SET THE TIME OFF |
-- +----------------------------------------+
--

SELECT 'END TIME: ' || TO_CHAR(sysdate, 'DD-MON-YYYY HH24:MI:SS') as End_Time
FROM dual;

spool off

--
-- +------------------+
-- | EXIT MAIN SCRIPT |
-- +------------------+
--

exit
