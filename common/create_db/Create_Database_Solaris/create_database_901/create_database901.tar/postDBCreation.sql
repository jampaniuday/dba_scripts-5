connect SYS/change_on_install as SYSDBA

set echo on

spool postDBCreation.log

CREATE SPFILE='$ORACLE_HOME/dbs/spfileORA901.ora' FROM pfile='$ORACLE_HOME/dbs/initORA901.ora';

spool off

REM +----------------------------------

connect SYS/change_on_install as SYSDBA

set echo on

spool postDBCreation2.log

shutdown immediate;
startup mount;
-- alter database archivelog;
alter database open;

spool off

exit;
