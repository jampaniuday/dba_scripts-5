connect SYS/change_on_install as SYSDBA

set echo on
spool context.log

@$ORACLE_HOME/ctx/admin/dr0csys change_on_install DRSYS TEMP;

connect CTXSYS/change_on_install
@$ORACLE_HOME/ctx/admin/dr0inst $ORACLE_HOME/lib/libctxx9.so;
@$ORACLE_HOME/ctx/admin/defaults/dr0defin.sql AMERICAN;

spool off
exit;
