connect SYS/change_on_install as SYSDBA

set echo on
spool postDBCreation1.log

REM +-------------------------------------------------+
REM | UTiLity script Recompile invalid Pl/sql modules |
REM +-------------------------------------------------+

connect SYS/change_on_install as SYSDBA

@$ORACLE_HOME/rdbms/admin/utlrp.sql;

REM +--------------------------+
REM | SHUTDOWN DATABASE        |
REM +--------------------------+

connect SYS/change_on_install as SYSDBA

shutdown immediate;

REM +-----------------------------------+
REM | MOUNT THE DATABASE &              |
REM | PUT DATABASE IN ARCHIVE LOG MODE  |
REM | SHUTDOWN THE DATABASE AGAIN       |
REM +-----------------------------------+

connect SYS/change_on_install as SYSDBA

startup mount;
-- alter database archivelog;
alter database open;

connect SYS/change_on_install as SYSDBA

shutdown immediate;

spool off

REM +-----------------------------------------------------+
REM | =================================================== |
REM | =================================================== |
REM +-----------------------------------------------------+

spool postDBCreation2.log

REM +--------------------------------------+
REM | CREATE SERVER MANAGED PARAMETER FILE |
REM +--------------------------------------+

connect SYS/change_on_install as SYSDBA

set echo on

CREATE SPFILE='$ORACLE_HOME/dbs/spfile$ORACLE_SID.ora' FROM pfile='$ORACLE_HOME/dbs/init$ORACLE_SID.ora';

REM +--------------------------------------+
REM | STARTUP DATABASE                     |
REM +--------------------------------------+

connect SYS/change_on_install as SYSDBA
startup open;

spool off
exit;
