/*******************************************************************
 *  rot13.c                                                        *
 *                                                                 *
 *  a simple implementation of the rot13 [en,de]coding scheme.     *
 *                                                                 *
 * Written by: Shawn Boyette, Kevin Turner, H�kon L�vdal           *
 * This software is free and is distributed under the terms of the *
 * GNU General Public License.  See the file COPYING for more info *
 *                                                                 *
 * usage: rot13 [options] <filename>                               *
 *        runs <filename> through a rot13 code routine and writes  *
 *        out the crypted file                                     *
 *                                                                 *
 * 1.0 - took input from prompt, ROT'd it and printf'ed it         *
 * 1.1 - runs over input file, accepts -o, -q, -h args             *
 * 1.2 - added -d arg, fixed problem with [,\,],^,_,and `          *
 * 1.3 - Uses stdin for default input (thanks to Kevin Turner      *
 *        (Acapnotic) for this) and stdout for output; can be      *
 *        piped in/out/through                                     *
 * 1.4 - Can handle multiple input files, improved arg handling,   *
 *        thanks to H�kon L�vdal. -q (quiet) becomes -s (stats)    *
 * 1.5 - Internal rewrite.  Can output multiple files with -g.     *
 *       Can ROT files "in place" with -p.  Found error that would *
 *       create files beginning with '-' (a Bad Thing)             *
 *******************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define ROT13VERSION "1.5"

/* Declare functions */
char ndcode(char translator);       /* conversion routine */
void help(void);                    /* onscreen help */
void print_stats(void);             /* end-of-run statistics */
int unlink(const char *pathname);         /* file deletion */
int movefile(const char *pathname);       /* file moving (for -p) */


char      *program_name;       /* name of the program */
char      delete_str[100];     /* command string for system() call */
char      move_str[100];       /* command string for system() call */
char      g_out_str[100];      /* string for output file with -g opt */
char      curr_arg = 0;        /* current argument from command line */
int       stats_flag = 0;      /* switch for -s option */
int       delete_flag = 0;     /* switch for -d option */
int       glob_flag = 0;       /* switch for -g option */
int       inplace_flag = 0;    /* switch for -p option */
int       char_in = 0;         /* character read from input file */
long int  total_chars = 0;     /* counter for chars in file */
long int  chars_conv = 0;      /* counter for converted chars */
float     percent = 0.0;        /* percentage converted */
FILE      *INFILE;             /* input file */
FILE      *OUTFILE;            /* output file */
char      *inputfilename = NULL;
char      *outputfilename = NULL;
extern int opterr;

int main(int argc, char *argv[]) {
  
  /* Tell the program it's name */
  program_name = argv[0];

  /*
   * Parse command line args
   */
  while(curr_arg != EOF) 
    {
      curr_arg = getopt(argc, argv, "sgpo:dvh");
      switch(curr_arg) 
	{
	case EOF:
	  break;
	case 's':
	  stats_flag = 1;
	  break;
	case 'o':
	  outputfilename = optarg;
	  break;
	case 'g':
	  glob_flag = 1;
	  break;
	case 'd':
	  delete_flag = 1;
	  break;
	case 'p':
	  inplace_flag = 1;
	  glob_flag = 1;
	  delete_flag = 1;
	  break;
	case 'v':
	  fprintf(stderr, "%s version " ROT13VERSION "\n", program_name);
	  exit(0);
	  break;
	case 'h':
	  help();
	  break;
	case '?':
	default:
	  (void)fprintf(stderr, "%s: Invalid option '-%c', ",
			program_name, optopt);
	  (void)fprintf(stderr, "Use -h to see available options.\n");
	  exit(1);
	  break;
	}
      
      if(optind == argc)        /* No files specified */
      {
	if(inplace_flag)
	  {
	    fprintf(stderr, "%s: Using -p without specifying an input",
		    program_name);
	    fprintf(stderr, " file makes no sense.\n");
	    exit(3);
	  }
	if(glob_flag)
	  {
	    fprintf(stderr, "%s: Using -g without specifying an input",
		    program_name);
	    fprintf(stderr, " file makes no sense.\n");
	    exit(2);
	  }
	argv[optind] = "-";   /* in order to enter the for loop below */
	argc++;
      }
  }
  
  /*
   * Set up output file
   */
  if(outputfilename == NULL)
    {
      if(!glob_flag) 
	{
	  OUTFILE = stdout;
	}
    } 
  else 
    {
      if(outputfilename[0] == '-')
	{
	  fprintf(stderr, "%s: when used, -o must be the last argument.\n",
		  program_name);
	  exit(12);
	}
      if(inplace_flag)
	{
	  fprintf(stderr, "%s: Options -p and -o are mutually exclusive.\n",
		  program_name);
	  exit(5);
	}
      if(glob_flag)
	{
	  fprintf(stderr, "%s: Options -g and -o are mutually exclusive.\n",
		  program_name);
	  exit(4);
	}
      OUTFILE = fopen(outputfilename, "w");
      if(OUTFILE == NULL) 
	{
	  fprintf(stderr, "%s: error writing file '%s\n", 
		  program_name, outputfilename);
	  perror("'");
	  exit(6);
	}
    }

  /*
   * Process all input files
   *
   * >>> Loop starts here <<<
   *
   */
  for(; optind < argc; optind++) 
    {
      /* do real output setup for -g option */
      if(glob_flag)
	{
	  (void)strcpy(g_out_str, argv[optind]);
	  (void)strcat(g_out_str, ".rot");
	  g_out_str[sizeof(g_out_str)] = '\0';
	  OUTFILE = fopen(g_out_str, "w");
	  if(OUTFILE == NULL) 
	    {
	      fprintf(stderr, "%s: error writing file '%s\n", 
		      program_name, g_out_str);
	      perror("'");
	      exit(7);
	    }
	}

      /* open input file */
      inputfilename = argv[optind];
      if(strcmp("-", inputfilename) == 0) 
	{
	  if (delete_flag)
	    {
	      fprintf(stderr, "%s: Using -d with no input", program_name);
	      fprintf(stderr, " file makes no sense\n");
	      exit(13);
	    }
	  INFILE = stdin;
	} 
      else 
	{
	  INFILE = fopen(inputfilename, "r");
	  if(INFILE == NULL) 
	    {
	      fprintf(stderr, "%s: %s does not seem to exist.\n", 
		      program_name, inputfilename);
	      exit(8);
	    }
	}

      /* rot file */
      while(1) 
	{
	  char_in = fgetc(INFILE);
	  if(char_in == EOF)
	    break;
	  total_chars++;
	  fputc(ndcode(char_in), OUTFILE);
	}

      /* close input/output files */
      if(INFILE != stdin)
	(void)fclose(INFILE);
      if(OUTFILE != stdout)
	(void)fclose(OUTFILE);

      /* take care of -p and -d */
      if(delete_flag)
	unlink(inputfilename);
      if(inplace_flag)
	movefile(inputfilename);
    }
  /*
   * >>> Loop ends here <<<
   */

  /* print stats if -s is thrown */
  if(stats_flag) 
    print_stats();

  /*close the output file if specified
   if(out_file != stdout)
   (void)fclose(out_file);*/

  return (0);
}



/*************************************
* ndcode - rot13 codec function      *
*                                    *
* ndcode...eNcode/Decode, get it?    *
* It's a joke, see...   :p           *
*                                    *
* parameters -                       *
*   translator -- char to be encoded *
*                 or decoded         *
*                                    *
* returns -                          *
*   the input character, run through *
*     rot13 coding                   *
*************************************/

char ndcode(char trans) {
  /* only encode letters... */
  if ((trans >= 65 && trans <= 90) || (trans >= 97 && trans <= 122)) {
    /*
     * rollback 26 if 'N' to 'Z' OR 'n' to 'z'
     * this will rot letters inside their own case
     * as per the example in the Hacker Jargon File 4.0
     */
    if (trans >= 78 && trans <= 90)
      trans -= 26;
    if (trans >= 110 && trans <= 122)
      trans -= 26;

    /* do rot13 encoding */
    trans += 13;
    chars_conv++;
  }
  return (trans);
}


/*****************************
* unlink - delete file       *
*                            *
* delete input file if -d    *
* switch is thrown           *
*****************************/
int unlink(const char *pathname) {
  (void)strcpy(delete_str, "rm ");
	  printf("%s", pathname);
  (void)strcat(delete_str, pathname);
	  printf("%s", pathname);
  delete_str[sizeof(delete_str)] = '\0';
	  printf("%s", pathname);
  system(delete_str);
  return(0);
}


/*****************************
* movefile - inplace file    *
*****************************/
int movefile(const char *pathname) {
  (void)strcpy(move_str, "mv ");
  (void)strcat(move_str, pathname);
  (void)strcat(move_str, ".rot ");
  (void)strcat(move_str, pathname);
  move_str[sizeof(move_str)] = '\0';
  system(move_str);
  return(0);
}


/********************************
* print_stats - print info      *
*                               *
* prints some stats to          *
* stderr if -s is thrown        *
********************************/
void print_stats(void) {
  if (total_chars < 1) {
    (void)fprintf(stderr, "\nCan't do stats for < 1 chars...Bailing out!\n\n");
    exit(9);
  }
  percent = ((float)chars_conv / (float)total_chars) * 100.0;
  
  (void)fprintf(stderr, "\nTotal characters read: %ld\n", total_chars);
  (void)fprintf(stderr, "Characters encoded   : %ld\n", chars_conv);
  (void)fprintf(stderr, "Encryption percentage: %f\n\n", percent);
}


/*****************************
* help - onscreen help func  *
*                            *
* prints out usage and       *
* options then exits with    *
* error return code          *
*****************************/
void help(void) {
  (void)fprintf(stderr, "\nrot13 1.5, 1998, Shawn Boyette, Kevin Turner, H�kon L�vdal\n");
  (void)fprintf(stderr, "Usage is: %s [options] [filelist]\n", program_name);
  (void)fprintf(stderr, "Where options are:\n");
  (void)fprintf(stderr, "    -h            Display this message\n");
  (void)fprintf(stderr, "    -v            Display version info\n");
  (void)fprintf(stderr, "    -g            Generate output filenames by appending '.rot'\n");
  (void)fprintf(stderr, "    -p            Overwrite original files (ROT in Place)\n");
  (void)fprintf(stderr, "    -d            Delete [filelist] after run\n");
  (void)fprintf(stderr, "    -s            Display end-of-run statistics\n");
  (void)fprintf(stderr, "    -o [filename] Send all output to [filename]\n\n");
  exit(0);
}


