
set arrays 72
set lines 110
set head off
set tab off
set pages 0
set serveroutput on format wrapped
