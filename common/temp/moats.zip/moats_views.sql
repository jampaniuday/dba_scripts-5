
create or replace view top
as
   select *
   from   table(moats.top);
