--
-- OraLatencyMap, a tool to visualize Oracle I/O latency using Heat Maps
--
-- Example1: db file sequential read
--

@@Example1_random_read.sql

